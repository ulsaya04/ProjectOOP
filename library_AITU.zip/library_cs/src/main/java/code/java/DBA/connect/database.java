package code.java.DBA.connect;

import java.sql.Connection;

public interface database {
    Connection getConnection();
}
