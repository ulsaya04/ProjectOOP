package code.java.fantasy;

public class ApplicationStarter extends Application{

}
